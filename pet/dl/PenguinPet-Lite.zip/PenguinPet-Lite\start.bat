@echo off
rem ?????? Edge ?"????"??????????????????
setlocal
set "HTML=%~dp0penguin-pet.html"
set "URL=file:///%HTML:\=/%"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%URL%" --window-size=1000,680
) else (
  start "" "%HTML%"
)